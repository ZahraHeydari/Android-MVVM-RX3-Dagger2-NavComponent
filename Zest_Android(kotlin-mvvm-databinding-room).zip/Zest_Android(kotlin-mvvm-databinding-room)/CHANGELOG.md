Changelog
=========
## Version 1.0.0
__2018-01-10__
* added `com.squareup.picasso:picasso:2.5.2`
* added `org.parceler:parceler-api:1.1.11` and 
annotationProcessor `org.parceler:parceler:1.1.11` to parse models
* added `org.greenrobot:greendao:3.2.2` to keep all internal data
* added `uk.co.chrisjenx:calligraphy:2.3.0` to apply desirable font
* added DatabaseManager to handle insert,update,delete,load and other operations
* added LifecycleLoggingActivity for logging various lifecycle events.
* used MVVM structure for implementation
* enabled data binding
* initial implementations


