package com.zest.android.category


import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.squareup.picasso.Picasso
import com.zest.android.R
import com.zest.android.category.CategoryAdapter.CategoryViewHolder
import com.zest.android.data.Category
import com.zest.android.databinding.HolderCategoryBinding
import java.util.*

/**
 * [android.support.v7.widget.RecyclerView.Adapter] to adapt
 * [Category] items into [RecyclerView] via [CategoryViewHolder]
 *
 * Created by ZARA on 09/30/2018.
 */
class CategoryAdapter(private val listener: OnCategoryFragmentInteractionListener) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    private val TAG = CategoryAdapter::class.java.name
    private val categories: MutableList<Category> = ArrayList()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val viewBinding =   HolderCategoryBinding.inflate(LayoutInflater.from(parent.context))
        return CategoryViewHolder(viewBinding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as CategoryViewHolder).onBind(getItem(position))
    }

    private fun getItem(position: Int): Category {
        return categories[position]
    }

    override fun getItemCount(): Int {
        return categories.size
    }

    fun addData(categories: List<Category>) {
        this.categories.clear()
        this.categories.addAll(categories)
        this.notifyDataSetChanged()
    }


    private inner class CategoryViewHolder(private val binding : HolderCategoryBinding)  {

         fun onBind(category: Category) {

             Picasso.with(binding.categoryImageView.context)
                     .load(category.image)
                     .placeholder(R.color.whiteSmoke)
                     .into(binding.categoryImageView)


             itemView.setOnClickListener{

             }
        }
    }
}