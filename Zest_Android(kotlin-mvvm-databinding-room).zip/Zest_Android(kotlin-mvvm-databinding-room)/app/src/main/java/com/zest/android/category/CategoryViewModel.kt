package com.zest.android.category

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import com.zest.android.data.Category
import com.zest.android.data.source.CategoryRepository


class CategoryViewModel : ViewModel {

    private lateinit var categoryRepository: CategoryRepository
    private val categoryData = MutableLiveData<Category>()
    private val isLoading = MutableLiveData<Boolean>()
    private val listener: OnCategoryFragmentInteractionListener

    constructor(category: Category, listener: OnCategoryFragmentInteractionListener) {
        this.listener = listener
        this.categoryData.value = category
    }

    constructor(categoryRepository: CategoryRepository, listener: OnCategoryFragmentInteractionListener) {
        this.categoryRepository = categoryRepository
        this.listener = listener
    }

    fun getTitle(): String {
        return categoryData.value?.title ?: ""
    }

    fun getImage(): String {
        return categoryData.value?.image ?: ""
    }

    fun getLoading(): Boolean {
        return this.isLoading.value!!
    }

    fun setLoading(isLoaded: Boolean) {
        this.isLoading.value = isLoaded
    }

    fun onCategoryClick() {
        categoryData.value?.let {
            listener.showSubCategories(it)
        }
    }

    fun loadCategories() {
        setLoading(true)
        categoryRepository.loadRootCategories(CategoriesCallbackImp())
    }

    /**
     * To make an interaction between [CategoryViewModel] and [CategoryRepository]
     */
    interface OnCategoriesCallback {

        fun loadData(categories: List<Category>)
    }

    inner class CategoriesCallbackImp : OnCategoriesCallback {

        override fun loadData(categories: List<Category>) {
            setLoading(false)
            listener.setResult(categories)
        }
    }

}