package com.zest.android.data

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Category(var id: Long? = null,
                    @SerializedName("strCategory") @Expose var title: String,
                    @SerializedName("idCategory") @Expose var categoryId: String? = null,
                    @SerializedName("strCategoryThumb") @Expose var image: String? = null,
                    @SerializedName("strCategoryDescription") @Expose var description: String? = null) : Parcelable {

}