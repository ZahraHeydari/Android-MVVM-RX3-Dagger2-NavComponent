package com.zest.android.data

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import java.util.*

@Parcelize
data class CategoryResponse(@SerializedName("categories") @Expose var categories: List<Category> = ArrayList()) : Parcelable