package com.zest.android.data

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.os.Parcelable
import android.support.annotation.NonNull
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity
data class Recipe(@SerializedName("idMeal") @Expose @NonNull @PrimaryKey var recipeId: String,
                  @SerializedName("strMeal") @Expose var title: String? = null,
                  @SerializedName("strMealThumb") @Expose var image: String? = null,
                  @SerializedName("strInstructions") @Expose var instructions: String? = null,
                  @SerializedName("strTags") @Expose var tag: String? = null) : Parcelable