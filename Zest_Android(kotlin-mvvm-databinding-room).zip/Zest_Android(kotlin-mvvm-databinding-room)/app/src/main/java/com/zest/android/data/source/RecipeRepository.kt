package com.zest.android.data.source

import android.util.Log
import com.zest.android.data.Recipe
import com.zest.android.data.RecipeResponse
import com.zest.android.data.source.local.DatabaseManager
import com.zest.android.data.source.remote.APIServices
import com.zest.android.data.source.remote.ServiceGenerator
import com.zest.android.home.RecipeViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

/**
 * To handle data operations. It provides a clean API so that the rest of the app can retrieve this data easily.
 * It knows where to get the data from and what API calls to make when data is updated.
 * You can consider repositories to be mediators between different data sources, such as persistent models,
 * web services, and caches.
 * @Author ZARA.
 */
class RecipeRepository {

    private val mApiServices: APIServices
    private val mDatabaseManager: DatabaseManager by lazy { DatabaseManager.getInstance() }

    init {
        mApiServices = ServiceGenerator.createService(APIServices::class.java)
    }

    fun updateRecipe(recipe: Recipe) {
        mDatabaseManager.recipeDao.update(recipe)
    }

    fun insertFavorite(recipe: Recipe) {
        mDatabaseManager.recipeDao.insert(recipe)
    }

    fun removeFavorite(recipe: Recipe) {
        mDatabaseManager.recipeDao.delete(recipe)
    }

    fun loadAllFavorites(): MutableList<Recipe> {
        return mDatabaseManager.recipeDao.loadAll()
    }

    fun deleteFavoriteRecipe(recipe: Recipe) {
        mDatabaseManager.recipeDao.delete(recipe)
    }

    fun loadRecipeList(resultCallback: RecipeViewModel.OnResultCallback) {
        mApiServices.getRecipes(generateRandomChar()).enqueue(RecipesResponseCallback(resultCallback))
    }

    private fun generateRandomChar():Char{
        return ('a' + (Math.random() * ('z'-'a' + 1)).toInt())
    }

    fun getFavoriteByRecipeId(recipe: Recipe): Recipe? {
        return mDatabaseManager.recipeDao.loadOneByRecipeId(recipe.recipeId)
    }

    fun deleteFavorite(recipe: Recipe) {
        mDatabaseManager.recipeDao.delete(recipe)
    }

    fun getAllRecipesByQuery(query: String, onSearchResultCallback: RecipeViewModel.OnResultCallback) {
        mApiServices.search(query).enqueue(SearchResponseCallback(onSearchResultCallback))
    }


    private inner class SearchResponseCallback(private val searchResultCallback:
                                               RecipeViewModel.OnResultCallback) : Callback<RecipeResponse> {

        override fun onResponse(call: Call<RecipeResponse>, response: Response<RecipeResponse>) {
            Log.d(TAG, "onResponse() called with: call = [" + call + "], response = [" + response.raw() + "]")
            if (response.isSuccessful) {
                val meals = response.body()
                if (meals?.recipes != null) {
                    searchResultCallback.loadData(meals.recipes)
                } else {
                    searchResultCallback.noData()
                }
            }
        }

        override fun onFailure(call: Call<RecipeResponse>, t: Throwable) {
            t.printStackTrace()
        }
    }

    private inner class RecipesResponseCallback(private val resultCallback: RecipeViewModel.OnResultCallback) : Callback<RecipeResponse> {

        override fun onResponse(call: Call<RecipeResponse>, response: Response<RecipeResponse>) {
            Log.d(TAG, "getRecipes onResponse() called with: call = [" + call + "], response = [" + response.raw() + "]")
            if (response.isSuccessful) {
                val meals = response.body()
                if (meals?.recipes != null && meals.recipes.isNotEmpty()) {
                    resultCallback.loadData(meals.recipes)
                } else {
                    resultCallback.noData()
                }
            }
        }

        override fun onFailure(call: Call<RecipeResponse>, t: Throwable) {
            t.printStackTrace()
        }
    }

    companion object {

        private val TAG = RecipeRepository::class.java.simpleName
    }
}
